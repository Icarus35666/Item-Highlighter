============================================================
Item Highlighter
Version 1.0 Stable
============================================================

1. OVERVIEW
------------------------------------------------------------

Item Highlighter helps users quickly locate and highlight
features across multiple layers using attribute values.

Instead of manually searching through attribute tables and
navigating between layers, users can select predefined
values from simple dropdown lists.

Matching features are automatically highlighted and the
map view zooms to their location.

------------------------------------------------------------
2. INSTALLATION
------------------------------------------------------------

1. Open QGIS.

2. Go to:

   Plugins > Manage and Install Plugins

3. Search for:

   Item Highlighter

4. Click Install.

------------------------------------------------------------
3. CONFIGURATION
------------------------------------------------------------

1. Open Item Highlighter.

2. Select the layers you want to use.

3. Select the attribute field associated with each layer.

4. Configure:

   - Border color
   - Fill color
   - Border width

5. Save your configuration.

------------------------------------------------------------
4. USING THE PLUGIN
------------------------------------------------------------

1. Open the plugin.

2. Select a value from a dropdown list.

3. The plugin will:

   - Locate matching features
   - Zoom to their location
   - Highlight them on the map

------------------------------------------------------------
5. SAVE / LOAD CONFIGURATIONS
------------------------------------------------------------

Configurations can be saved as JSON files.

Available functions:

- Save configuration
- Load configuration
- Reset configuration

------------------------------------------------------------
6. FEATURES
------------------------------------------------------------

- Support for up to 10 layers
- Automatic zoom
- Feature highlighting
- Custom colors
- Custom line width
- JSON configuration storage
- Multiple project support
- Missing layer detection
- Missing feature detection

------------------------------------------------------------
7. AUTHOR
------------------------------------------------------------

François Thouanel
INSA Rennes

============================================================

