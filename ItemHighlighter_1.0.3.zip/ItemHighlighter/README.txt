============================================================
Item Highlighter
Version 1.0.3
============================================================

1. OVERVIEW
------------------------------------------------------------

Item Highlighter helps users quickly locate and highlight
features across multiple layers using attribute values.

Instead of manually searching through attribute tables and
navigating between layers, users can select predefined
values from simple dropdown lists.

Matching features are automatically highlighted and the
map view zooms to their location.

------------------------------------------------------------
2. INSTALLATION
------------------------------------------------------------

1. Open QGIS.

2. Go to:

   Plugins > Manage and Install Plugins
   For QGIS3 :(C:\Users\"..."\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\item_highlighter)
   For QGIS4 :(C:\Users\"..."\AppData\Roaming\QGIS\QGIS4\profiles\default\python\plugins\item_highlighter)
3. Restart QGIS.

3. Search for:

   Item Highlighter

4. Click Install.

------------------------------------------------------------
3. CONFIGURATION
------------------------------------------------------------

1. Open Item Highlighter.

2. Select the layers you want to use.

3. Select the attribute field associated with each layer.

4. Configure:

   - Border color
   - Fill color
   - Border width

5. Save your configuration.

------------------------------------------------------------
4. USING THE PLUGIN
------------------------------------------------------------

1. Open the plugin.

2. Select a value from a dropdown list.

3. The plugin will:

   - Locate matching features
   - Zoom to their location
   - Highlight them on the map

------------------------------------------------------------
5. SAVE / LOAD CONFIGURATIONS
------------------------------------------------------------

Configurations can be saved as JSON files.

Available functions:

- Save configuration
- Load configuration
- Reset configuration

------------------------------------------------------------
6. FEATURES
------------------------------------------------------------

- Support for up to 10 layers
- Automatic zoom
- Feature highlighting
- Custom colors
- Custom line width
- JSON configuration storage
- Multiple project support
- Missing layer detection
- Missing feature detection


------------------------------------------------------------
8. CHANGELOG
------------------------------------------------------------

    Version 1.0 Stable
    - Added JSON save/load support
    - Added reset button
    - Added layer not found warning
    - Added no feature found warning
    - Improved dialog management
    - Improved canvas interaction
    - Prevented multiple plugin instances
    - Improved configuration handling
	Version 1.0.1
	- Added QGIS 4 / Qt6 compatibility
	- Updated metadata
	- Updated changelog
	- Fixed Qt5/Qt6 compatibility issues
	Version 1.0.2
	- Try to fix Qt6 check issue on Qgis plugin repository
	Version 1.0.3
	- Fix the issue where the setting doesn't apply when setting up a new configuration without restarting the plugin.
------------------------------------------------------------
7. AUTHOR
------------------------------------------------------------

François Thouanel
INSA Rennes

============================================================

